# Start here: POLARIS-X

This package contains the runnable Python application, original Colab notebook,
scientific documentation, tests, and pre-generated results.

## Fastest presentation: no installation

1. Open outputs/kirsch/POLARIS_X_Main_Results.png.
2. Open outputs/kirsch/POLARIS_X_Analyzer_Sweep.png.
3. Open outputs/fea/POLARIS_X_Deformation.png.
4. Read docs/VALIDATION.md before discussing reconstruction accuracy.

## Run on Windows

Install Python 3.12 from https://www.python.org/downloads/ and enable Add Python to PATH.
Extract this ZIP completely. Open PowerShell in the extracted POLARIS-X folder.
Run each line separately:

    py -3.12 -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -e .
    .\.venv\Scripts\python.exe -m streamlit run app.py

Keep the terminal open. Streamlit prints the local browser address.
Stop with Ctrl+C. For subsequent runs, use only the final command.

## Run on macOS or Linux

Install Python 3.12. Extract the ZIP. Open Terminal in the POLARIS-X folder.

    python3 -m venv .venv
    .venv/bin/python -m pip install -e .
    .venv/bin/python -m streamlit run app.py

Keep the terminal open. Streamlit prints the local browser address.
Stop with Ctrl+C. For subsequent runs, use only the final command.

## Run the notebook online

Open https://colab.research.google.com, upload
notebooks/POLARIS-X_Colab_Simulation_VERIFIED.ipynb, and select Runtime > Run all.
Use its supplied default parameters for the verified notebook run.
The expanded FEA/calibration/reconstruction interface is in app.py, not in the
original notebook. Use the application to change experiments interactively.

## Five-minute demonstration

1. Analytical Kirsch model: 1000 N, analyzer 90 degrees.
2. Explain stress difference, phase retardation and synthetic RGB.
3. Open Analyzer & camera and compare 0, 45, 90, 135 degrees.
4. Change force to 1500 N and analyzer to 45 degrees.
5. Choose Finite plate FEA and open Mechanics & exports.
6. Show the mesh and magnified deformation.
7. Run physics checks in Verification.
8. If discussing inversion, show both accuracy and resolved-pixel coverage.

## Scientific context

The Kirsch model is an infinite plate; the rectangle is a viewing window.
The native FEA model is a simplified finite plate with one centered hole.
Default material constants and example calibration files are illustrative.
Reconstruction assumes known principal-axis orientation and reports unresolved pixels.
This is not experimentally validated failure prediction or a physical digital twin.
See README.md, docs/METHODS.md, and docs/VALIDATION.md.

## Share

Share this ZIP, the notebook, or exported PNG figures by your preferred method.
A local app's address works on your own computer; it is not a public hosted site.
Public deployment is a separate step. This download does not publish to GitHub.

## Audited figures
The figures were audited and corrected on 9 October 2026. See docs/FIGURE_AUDIT.md. Use the updated presentation figures. The inverse example has incomplete coverage and some large accepted errors; do not present it as full stress recovery.
